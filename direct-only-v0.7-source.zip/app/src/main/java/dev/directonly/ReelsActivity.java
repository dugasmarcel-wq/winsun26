package dev.directonly;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Reels-only foreground browser with twenty-five-minute daily budget. */
public final class ReelsActivity extends Activity {
    private ReelsBudget budget;
    private WebView web;
    private TextView counter;
    private boolean foreground;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable() {
        public void run() {
            if(!foreground || budget==null)return;
            long ms=budget.remainingMillis(),secs=(ms+999)/1000;
            counter.setText(String.format(Locale.ROOT,"Reels %d:%02d",secs/60,secs%60));
            if(ms==0){
                Toast.makeText(ReelsActivity.this,"25-minute Reels limit reached.",Toast.LENGTH_LONG).show();
                finish();
            }else handler.postDelayed(this,250);
        }
    };
    private boolean allowed(String url){
        return UrlPolicy.reelsFeedUrl(url) ||
               UrlPolicy.classify(url)==UrlPolicy.Destination.SINGLE_REEL ||
               UrlPolicy.classify(url)==UrlPolicy.Destination.LOGIN;
    }
    private static final String JS=
        "(function(){if(window.__doReelsGuard)return;window.__doReelsGuard=1;"+
        "function ok(h){try{var u=new URL(h,location.href);if(u.protocol!=='https:'||"+
        "!['www.instagram.com','instagram.com'].includes(u.hostname))return false;"+
        "var p=u.pathname;return p==='/reels/'||p==='/reels'||"+
        "/^\\/reels?\\/[a-zA-Z0-9_-]+\\/?$/.test(p)||p.startsWith('/accounts/login');"+
        "}catch(e){return false}}"+
        "document.addEventListener('click',function(e){var a=e.target.closest('a[href]');"+
        "if(a&&!ok(a.href)){e.preventDefault();e.stopImmediatePropagation()}},true);"+
        "setInterval(function(){if(!ok(location.href))location.replace('https://www.instagram.com/reels/')},350);"+
        "})();";
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        budget=new ReelsBudget(this);
        LinearLayout frame=new LinearLayout(this);frame.setOrientation(LinearLayout.VERTICAL);
        frame.setBackgroundColor(Color.rgb(18,18,18));setContentView(frame);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);
        Button back=new Button(this);back.setText("Back to DMs");back.setOnClickListener(v->finish());
        bar.addView(back);counter=new TextView(this);counter.setTextSize(14);counter.setTextColor(Color.WHITE);
        counter.setPadding(12,18,0,0);bar.addView(counter);frame.addView(bar);
        web=new WebView(this);WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);settings.setSafeBrowsingEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){
                return req.isForMainFrame() && !allowed(req.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return !allowed(url);}
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){
                if(!allowed(url)){view.stopLoading();finish();}
            }
            @Override public void onPageFinished(WebView view,String url){
                if(allowed(url))view.evaluateJavascript(JS,null);
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onCreateWindow(WebView v,boolean d,boolean g,android.os.Message r){return false;}
        });
        frame.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.loadUrl(UrlPolicy.REELS_FEED);
    }
    @Override protected void onResume(){
        super.onResume();foreground=true;
        if(!budget.begin()){Toast.makeText(this,"No Reels time remains today.",Toast.LENGTH_LONG).show();finish();return;}
        handler.removeCallbacks(tick);handler.post(tick);
        if(web!=null)web.onResume();
    }
    @Override protected void onPause(){
        foreground=false;handler.removeCallbacks(tick);if(budget!=null)budget.stop();
        if(web!=null)web.onPause();super.onPause();
    }
    @Override protected void onDestroy(){
        if(web!=null){web.stopLoading();web.destroy();web=null;}
        super.onDestroy();
    }
}

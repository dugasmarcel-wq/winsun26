package dev.directonly;
import android.content.Context;
import android.content.SharedPreferences;
import java.time.LocalDate;
/** Persistent allowance of ten Shorts per device-local day. */
public final class ShortsBudget {
  private final SharedPreferences prefs;
  public ShortsBudget(Context c){prefs=c.getApplicationContext().getSharedPreferences("shorts_allowance_v1",Context.MODE_PRIVATE);}
  private void reset(){
    String day=LocalDate.now().toString(),previous=prefs.getString("day","");
    if(previous.isEmpty() || day.compareTo(previous)>0)
      prefs.edit().putString("day",day).putInt("count",0).commit();
  }
  public synchronized int remaining(){reset();return Math.max(0,10-prefs.getInt("count",0));}
  public synchronized boolean useOne(){
    reset();int n=prefs.getInt("count",0);
    return n<10 && prefs.edit().putInt("count",n+1).commit();
  }
}

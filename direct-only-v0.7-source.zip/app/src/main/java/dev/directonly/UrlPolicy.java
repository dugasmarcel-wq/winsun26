package dev.directonly;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deliberately small first-party allowlist. No broad subdomain or external URL allowances. */
public final class UrlPolicy {
    public static final String INBOX = "https://www.instagram.com/direct/inbox/";
    public static final String HOME = "https://www.instagram.com/";
    public static final String REELS_FEED = "https://www.instagram.com/reels/";
    private static final Pattern REEL = Pattern.compile("^/(?:reel|reels)/([a-zA-Z0-9_-]+)/?$");

    public enum Destination { MESSAGES, LOGIN, SINGLE_REEL, HOME, BLOCKED }
    private UrlPolicy() { }

    public static Destination classify(String raw) {
        URI u = parse(raw);
        if (u == null || !"https".equalsIgnoreCase(u.getScheme()) || !isInstagramHost(u.getHost())) {
            return Destination.BLOCKED;
        }
        String path = u.getRawPath();
        if (path == null || path.isEmpty() || "/".equals(path)) return Destination.HOME;
        if (path.equals("/direct") || path.startsWith("/direct/")) return Destination.MESSAGES;
        if (isLoginPath(path)) return Destination.LOGIN;
        if (REEL.matcher(path).matches()) return Destination.SINGLE_REEL;
        return Destination.BLOCKED;
    }

    public static boolean reelsFeedUrl(String raw) {
        URI u=parse(raw);
        if(u==null || !"https".equalsIgnoreCase(u.getScheme()) || !isInstagramHost(u.getHost()))return false;
        String p=u.getRawPath();
        return "/reels".equals(p) || "/reels/".equals(p);
    }
    public static boolean sameReel(String a, String b) {
        String x = reelId(a), y = reelId(b);
        return x != null && x.equals(y);
    }

    public static String reelId(String raw) {
        if (classify(raw) != Destination.SINGLE_REEL) return null;
        URI u = parse(raw);
        Matcher m = REEL.matcher(u.getRawPath());
        return m.matches() ? m.group(1) : null;
    }

    private static URI parse(String raw) {
        if (raw == null) return null;
        try { return new URI(raw); }
        catch (URISyntaxException | IllegalArgumentException e) { return null; }
    }

    private static boolean isInstagramHost(String host) {
        return host != null && (host.equalsIgnoreCase("www.instagram.com") || host.equalsIgnoreCase("instagram.com"));
    }

    private static boolean isLoginPath(String p) {
        return p.equals("/accounts/login") || p.startsWith("/accounts/login/") ||
                p.equals("/accounts/onetap") || p.startsWith("/accounts/onetap/") ||
                p.equals("/accounts/password") || p.startsWith("/accounts/password/") ||
                p.equals("/accounts/two_factor") || p.startsWith("/accounts/two_factor/") ||
                p.equals("/accounts/confirm") || p.startsWith("/accounts/confirm/") ||
                p.equals("/challenge") || p.startsWith("/challenge/") ||
                p.equals("/accounts/suspended") || p.startsWith("/accounts/suspended/") ||
                p.equals("/accounts/signup") || p.startsWith("/accounts/signup/");
    }
}

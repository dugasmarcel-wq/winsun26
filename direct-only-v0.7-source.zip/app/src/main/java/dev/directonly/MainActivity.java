package dev.directonly;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ComponentName;
import android.provider.Settings;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioManager;
import java.util.Locale;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** DM-only wrapper for instagram.com. No Instagram passwords or messages are read by this app. */
public final class MainActivity extends Activity {
    public static final String ACTION_SHOW_INBOX = "dev.directonly.action.SHOW_INBOX";
    private static final int REQUEST_PICK_FILE = 1438;
    private final int black = Color.rgb(18, 18, 18);
    private final int grey = Color.rgb(190, 190, 190);
    private FrameLayout root;
    private LinearLayout messagesSurface;
    private LinearLayout reelSurface;
    private FrameLayout inboxFrame;
    private FrameLayout inlineShield;
    private WebView messages;
    private LockedReelWebView reel;
    private String activeReel;
    private ValueCallback<Uri[]> pendingFiles;
    private String inboxScript;
    private String reelScript;
    private boolean exiting;
    private volatile boolean foreground;
    private HomeBudget homeBudget;
    private ReelsBudget reelsBudget;
    private boolean inlineVideoOpen;
    private Button homeButton;
    private final Handler usageHandler = new Handler(Looper.getMainLooper());
    private final Runnable usageTick = new Runnable() {
        @Override public void run() {
            if (exiting) return;
            if (homeBudget != null) {
                long remaining = homeBudget.remainingMillis();
                if (homeBudget.isRunning() && remaining == 0) {
                    homeBudget.stop();
                    if (messages != null) messages.loadUrl(UrlPolicy.INBOX);
                    Toast.makeText(MainActivity.this, "Home time used. Messages remain available.", Toast.LENGTH_LONG).show();
                }
                updateHomeButton();
            }
            if(reelsBudget!=null && reelsBudget.isRunning() && reelsBudget.remainingMillis()==0){
                reelsBudget.stop();inlineVideoOpen=false;
                if(inlineShield!=null)inlineShield.setVisibility(View.GONE);
                if(reel!=null)closeReel();
                if(messages!=null)messages.loadUrl(UrlPolicy.INBOX);
                Toast.makeText(MainActivity.this,"Daily Reels allowance used.",Toast.LENGTH_LONG).show();
            }
            usageHandler.postDelayed(this, 250);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(black);
        getWindow().setNavigationBarColor(black);
        inboxScript = readAsset("direct_guard.js");
        reelScript = readAsset("reel_guard.js");
        homeBudget = new HomeBudget(this);
        reelsBudget = new ReelsBudget(this);
        buildUi();
        usageHandler.post(usageTick);
        messages.loadUrl(UrlPolicy.INBOX);
        Updater.register(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 733);
        }
        Updater.check(this, false);
        // The two services require explicit Android Settings approval. Without it,
        // Direct Only cannot redirect native Instagram launches or mirror DMs.
        if (!getPreferences(MODE_PRIVATE).getBoolean("protect_setup_v5_shown", false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("protect_setup_v5_shown", true).apply();
            new Handler(Looper.getMainLooper()).postDelayed(this::showProtectionSetup, 700);
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(black);
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            root.setPadding(0, top, 0, bottom);
            return insets;
        });
        messagesSurface = new LinearLayout(this);
        messagesSurface.setOrientation(LinearLayout.VERTICAL);
        messagesSurface.setBackgroundColor(black);
        root.addView(messagesSurface, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout toolbar = toolbar();
        TextView title = label("DIRECT ONLY", 15, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        toolbar.addView(button("Inbox", v -> goInbox()));
        homeButton = button("Home 5:00", v -> enterHome());
        toolbar.addView(homeButton);
        toolbar.addView(button("Reels", v -> {
            if(reelsBudget.remainingMillis()==0)Toast.makeText(this,
                "Reels limit reached. Resets at midnight.",Toast.LENGTH_LONG).show();
            else startActivity(new Intent(this,ReelsActivity.class));
        }));
        toolbar.addView(button("More", v -> showMenu()));
        messagesSurface.addView(toolbar);

        messages = new WebView(this);
        configureWebView(messages);
        messages.addJavascriptInterface(new InboxBridge(), "DirectOnlyAndroid");
        messages.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return decideInboxNavigation(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return decideInboxNavigation(url);
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (inlineShield != null) inlineShield.setVisibility(View.GONE);
                UrlPolicy.Destination d = UrlPolicy.classify(url);
                if (d == UrlPolicy.Destination.HOME) {
                    if (foreground && homeBudget.begin()) { updateHomeButton(); return; }
                    view.stopLoading();
                    view.post(() -> view.loadUrl(UrlPolicy.INBOX));
                    return;
                }
                homeBudget.stop();
                updateHomeButton();
                if (d == UrlPolicy.Destination.BLOCKED || d == UrlPolicy.Destination.SINGLE_REEL) {
                    view.stopLoading();
                    if (d == UrlPolicy.Destination.SINGLE_REEL) showSingleReel(url);
                    else if (d == UrlPolicy.Destination.BLOCKED) notifyBlocked();
                    view.post(() -> view.loadUrl(UrlPolicy.INBOX));
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (UrlPolicy.classify(url) == UrlPolicy.Destination.MESSAGES ||
                        UrlPolicy.classify(url) == UrlPolicy.Destination.LOGIN ||
                        UrlPolicy.classify(url) == UrlPolicy.Destination.HOME) {
                    view.evaluateJavascript(inboxScript, null);
                }
            }
        });
        messages.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = cb;
                Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("*/*");
                picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(picker, "Select message attachment"), REQUEST_PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFiles.onReceiveValue(null);
                    pendingFiles = null;
                    return false;
                }
            }
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                                                    boolean isUserGesture, android.os.Message resultMsg) {
                notifyBlocked();
                return false;
            }
        });
        inboxFrame = new FrameLayout(this);
        inboxFrame.addView(messages, new FrameLayout.LayoutParams(-1, -1));

        // The native layer consumes ALL touches in Instagram's inline media popup,
        // regardless of whether that popup changes the browser URL.
        inlineShield = new FrameLayout(this);
        inlineShield.setVisibility(View.GONE);
        inlineShield.addView(blockingGlass(), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout mediaBar = toolbar();
        mediaBar.addView(button("Back to chat", v -> {
            inlineShield.setVisibility(View.GONE);
            inlineVideoOpen=false;reelsBudget.stop();
            String chat = messages.getUrl();
            messages.loadUrl(UrlPolicy.classify(chat) == UrlPolicy.Destination.MESSAGES
                    ? chat : UrlPolicy.INBOX);
        }));
        mediaBar.addView(button("Play / Pause", v -> {
            enableMediaAudio();
            messages.evaluateJavascript("window.DirectOnlyInline&&window.DirectOnlyInline.togglePlayback()", null);
        }));
        mediaBar.addView(button("Sound on", v -> {
            enableMediaAudio();
            messages.evaluateJavascript("window.DirectOnlyInline&&window.DirectOnlyInline.enableSound()", null);
        }));
        FrameLayout.LayoutParams barPosition = new FrameLayout.LayoutParams(-1, dp(58), Gravity.BOTTOM);
        inlineShield.addView(mediaBar, barPosition);
        inboxFrame.addView(inlineShield, new FrameLayout.LayoutParams(-1, -1));
        messagesSurface.addView(inboxFrame, new LinearLayout.LayoutParams(-1, 0, 1));

        reelSurface = new LinearLayout(this);
        reelSurface.setOrientation(LinearLayout.VERTICAL);
        reelSurface.setBackgroundColor(black);
        reelSurface.setVisibility(View.GONE);
        root.addView(reelSurface, new FrameLayout.LayoutParams(-1, -1));
    }

    private void configureWebView(WebView web) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // needed for user-selected DM attachments
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setBackgroundColor(Color.WHITE);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private boolean decideInboxNavigation(String url) {
        UrlPolicy.Destination dest = UrlPolicy.classify(url);
        if (dest == UrlPolicy.Destination.MESSAGES || dest == UrlPolicy.Destination.LOGIN) {
            homeBudget.stop();
            updateHomeButton();
            return false;
        }
        if (dest == UrlPolicy.Destination.HOME) {
            if (foreground && homeBudget.begin()) { updateHomeButton(); return false; }
            goInbox();
            return true;
        }
        if (dest == UrlPolicy.Destination.SINGLE_REEL) {
            if (UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.MESSAGES) showSingleReel(url);
            else notifyBlocked();
        } else {
            notifyBlocked();
        }
        return true;
    }

    private void showSingleReel(String url) {
        if (UrlPolicy.classify(url) != UrlPolicy.Destination.SINGLE_REEL) return;
        if(!foreground || reelsBudget.remainingMillis()==0){
            Toast.makeText(this,"Daily Reels allowance used.",Toast.LENGTH_LONG).show();return;
        }
        if (reel != null) closeReel();
        reelsBudget.begin();
        activeReel = url;
        reelSurface.removeAllViews();
        LinearLayout toolbar = toolbar();
        toolbar.addView(button("Back to messages", v -> closeReel()));
        toolbar.addView(button("Play / Pause", v -> {
            enableMediaAudio();
            if (reel != null) reel.evaluateJavascript(
                    "window.DirectOnlyReel&&window.DirectOnlyReel.togglePlayback()", null);
        }));
        toolbar.addView(button("Sound on", v -> {
            enableMediaAudio();
            if (reel != null) reel.evaluateJavascript(
                    "window.DirectOnlyReel&&window.DirectOnlyReel.enableSound()", null);
        }));
        TextView hint = label("One Reel only", 12, grey);
        toolbar.addView(hint, new LinearLayout.LayoutParams(0, dp(52), 1));
        reelSurface.addView(toolbar);

        reel = new LockedReelWebView(this);
        configureWebView(reel);
        // A native button controls playback, because the Instagram document has no touch access.
        reel.getSettings().setMediaPlaybackRequiresUserGesture(false);
        reel.setBackgroundColor(Color.BLACK);
        reel.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return request.isForMainFrame() && rejectReelNavigation(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return rejectReelNavigation(url);
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                if (!UrlPolicy.sameReel(activeReel, url)) {
                    view.stopLoading();
                    notifyBlocked();
                    closeReel();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (UrlPolicy.sameReel(activeReel, url)) {
                    String locked = reelScript.replace("__DIRECT_ONLY_REEL_ID__", UrlPolicy.reelId(activeReel));
                    view.evaluateJavascript(locked, null);
                }
            }
        });
        reel.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean dialog,
                                                    boolean gesture, android.os.Message msg) {
                notifyBlocked();
                return false;
            }
        });
        FrameLayout lockedFrame = new FrameLayout(this);
        lockedFrame.addView(reel, new FrameLayout.LayoutParams(-1, -1));
        lockedFrame.addView(blockingGlass(), new FrameLayout.LayoutParams(-1, -1));
        reelSurface.addView(lockedFrame, new LinearLayout.LayoutParams(-1, 0, 1));
        reelSurface.setVisibility(View.VISIBLE);
        reel.loadUrl(url);
    }

    private boolean rejectReelNavigation(String url) {
        if (UrlPolicy.sameReel(activeReel, url)) return false;
        notifyBlocked();
        return true;
    }

    private void closeReel() {
        if (reel == null) return;
        reelSurface.setVisibility(View.GONE);
        reel.stopLoading();
        reel.loadUrl("about:blank");
        ViewGroup parent = (ViewGroup) reel.getParent();
        if (parent != null) parent.removeView(reel);
        reelSurface.removeAllViews();
        reel.destroy();
        reel = null;
        activeReel = null;
        if(!inlineVideoOpen && reelsBudget!=null)reelsBudget.stop();
    }

    /** Native input interception: Instagram cannot see taps, swipes, or carousel controls. */
    private View blockingGlass() {
        View glass = new View(this);
        glass.setClickable(true);
        glass.setOnTouchListener((v, event) -> true);
        glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return glass;
    }

    private class InboxBridge {
        @JavascriptInterface
        public void openReel(String url) {
            runOnUiThread(() -> {
                if (UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.MESSAGES &&
                        UrlPolicy.classify(url) == UrlPolicy.Destination.SINGLE_REEL) showSingleReel(url);
                else notifyBlocked();
            });
        }
        @JavascriptInterface
        public void setInlineVideoOpen(boolean isOpen) {
            runOnUiThread(() -> {
                if(inlineShield!=null && reel==null){
                    if(isOpen && (!foreground || reelsBudget.remainingMillis()==0)){
                        inlineVideoOpen=false;inlineShield.setVisibility(View.GONE);
                        messages.loadUrl(UrlPolicy.INBOX);
                    }else{
                        inlineVideoOpen=isOpen;
                        if(isOpen)reelsBudget.begin();else reelsBudget.stop();
                        inlineShield.setVisibility(isOpen ? View.VISIBLE : View.GONE);
                    }
                }
            });
        }
        @JavascriptInterface
        public boolean mayViewHome() { return foreground && homeBudget.remainingMillis() > 0L; }
        @JavascriptInterface
        public void homeRoute(boolean home) {
            runOnUiThread(() -> {
                if (home) {
                    if (!foreground || !homeBudget.begin()) goInbox();
                } else homeBudget.stop();
                updateHomeButton();
            });
        }
        @JavascriptInterface
        public void blocked() { runOnUiThread(() -> notifyBlocked()); }
        @JavascriptInterface
        public void guardViolation() {
            runOnUiThread(() -> {
                if (UrlPolicy.classify(messages.getUrl()) != UrlPolicy.Destination.MESSAGES &&
                        UrlPolicy.classify(messages.getUrl()) != UrlPolicy.Destination.LOGIN &&
                        !(UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.HOME &&
                          foreground && homeBudget.remainingMillis() > 0)) {
                    messages.loadUrl(UrlPolicy.INBOX);
                }
            });
        }
    }

    private void showMenu() {
        new AlertDialog.Builder(this)
            .setTitle("Direct Only")
            .setItems(new String[]{"Set up Instagram + YouTube blockers and DM alerts", "Check for updates", "Install downloaded update", "Restrictions / privacy"},
                (dialog, which) -> {
                    if (which == 0) showProtectionSetup();
                    if (which == 1) Updater.check(this, true);
                    if (which == 2) {
                        if (Updater.hasPending(this)) startActivity(new Intent(this, InstallUpdateActivity.class));
                        else Toast.makeText(this, "No verified update has been downloaded yet.", Toast.LENGTH_LONG).show();
                    }
                    if (which == 3) new AlertDialog.Builder(this)
                        .setTitle("Daily allowances")
                        .setMessage("Five minutes of Home feed browsing per local calendar day, resetting at midnight. " +
                            "Only time spent viewing Home with this app in the foreground is counted. " +
                            "Reels: 25 minutes daily (remaining " + (reelsBudget.remainingMillis()/1000) + " seconds). " +
                             "YouTube Shorts: 10 daily (remaining " + new ShortsBudget(this).remaining() + "). " +
                             "All allowances reset at phone-local midnight. " +
                            "The same Accessibility permission blocks the native Instagram interface and YouTube Shorts. " +
                            "Instagram's website may change and interfere with blocking. " +
                            "Updates are checked automatically and downloaded from the Direct Only GitHub Releases feed. " +
                            "Android must approve each APK installation.")
                        .setPositiveButton("OK", null).show();
                }).show();
    }

    private void showProtectionSetup() {
        boolean blocking = serviceEnabled(InstagramBlockService.class,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean alerts = serviceEnabled(InstagramDmNotifications.class,
                "enabled_notification_listeners");
        new AlertDialog.Builder(this)
            .setTitle("Instagram + YouTube blockers and DM notifications")
            .setMessage("Instagram blocking + YouTube Shorts blocking: " + (blocking ? "ON" : "OFF") +
                    "\nDM notification forwarding: " + (alerts ? "ON" : "OFF") +
                    "\n\nKeep official Instagram installed and signed in for background DM alerts. " +
                    "Enable Accessibility for the Instagram launch blocker AND YouTube Shorts blocker. " +
                    "Ten Shorts are allowed daily; YouTube videos, Home and search remain available. " +
                    "YouTube Accessibility signal changes can cause missed or extra Shorts counts. " +
                    "Enable Notification access to forward Instagram DMs into Direct Only. " +
                    "The app only examines YouTube interface labels for blocking; it does not store them.")
            .setPositiveButton("Enable both blockers", (d, w) ->
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
            .setNeutralButton("Enable DM alerts", (d, w) ->
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)))
            .setNegativeButton("Later", null)
            .show();
    }

    private boolean serviceEnabled(Class<?> type, String settingName) {
        String enabled = Settings.Secure.getString(getContentResolver(), settingName);
        if (enabled == null) return false;
        String component = new ComponentName(this, type).flattenToString();
        return (":" + enabled + ":").contains(":" + component + ":");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && ACTION_SHOW_INBOX.equals(intent.getAction())) {
            if (reel != null) closeReel();
            if (inlineShield != null) inlineShield.setVisibility(View.GONE);
            goInbox();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        if (messages != null && UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.HOME) {
            if (!homeBudget.begin()) goInbox();
        }
        updateHomeButton();
        if((reel!=null || inlineVideoOpen) && !reelsBudget.begin()){
            if(reel!=null)closeReel();
            inlineVideoOpen=false;if(inlineShield!=null)inlineShield.setVisibility(View.GONE);
            goInbox();
        }
        if (getIntent() != null && ACTION_SHOW_INBOX.equals(getIntent().getAction())) {
            if (reel != null) closeReel();
            goInbox();
            getIntent().setAction(null);
        }
        Updater.maybePromptOnResume(this);
    }

    @Override protected void onPause() {
        foreground = false;
        if (homeBudget != null) homeBudget.stop();
        if (reelsBudget != null) reelsBudget.stop();
        super.onPause();
    }

    private void enterHome() {
        if (!foreground || !homeBudget.begin()) {
            updateHomeButton();
            Toast.makeText(this, "Daily Home time used. Resets at midnight.", Toast.LENGTH_LONG).show();
            return;
        }
        if (reel != null) closeReel();
        if (inlineShield != null) inlineShield.setVisibility(View.GONE);
        updateHomeButton();
        messages.loadUrl(UrlPolicy.HOME);
    }

    private void goInbox() {
        if (homeBudget != null) homeBudget.stop();
        updateHomeButton();
        if (messages != null) messages.loadUrl(UrlPolicy.INBOX);
    }

    private void updateHomeButton() {
        if (homeButton == null || homeBudget == null) return;
        long ms = homeBudget.remainingMillis();
        long seconds = (ms + 999) / 1000;
        homeButton.setText(String.format(Locale.ROOT, "Home %d:%02d", seconds / 60, seconds % 60));
        homeButton.setEnabled(ms > 0);
    }

    private void enableMediaAudio() {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audio != null) {
            audio.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
        }
    }

    private void notifyBlocked() {
        if (!exiting) Toast.makeText(this, "Blocked. Only messages and shared Reels are available.", Toast.LENGTH_SHORT).show();
    }

    private LinearLayout toolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setBackgroundColor(black);
        t.setPadding(dp(12), 0, dp(7), 0);
        t.setMinimumHeight(dp(52));
        return t;
    }

    private Button button(String name, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(name);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(47, 47, 47)));
        b.setOnClickListener(click);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private TextView label(String text, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) { throw new IllegalStateException("Missing required guard: " + name, e); }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_PICK_FILE || pendingFiles == null) return;
        Uri[] resultUris = null;
        if (result == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                android.content.ClipData clip = data.getClipData();
                resultUris = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) resultUris[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                resultUris = new Uri[]{data.getData()};
            }
        }
        pendingFiles.onReceiveValue(resultUris);
        pendingFiles = null;
    }

    @Override
    public void onBackPressed() {
        if (reel != null) { closeReel(); return; }
        if (messages != null && UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.HOME) { goInbox(); return; }
        if (messages != null && messages.canGoBack()) { messages.goBack(); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        exiting = true;
        usageHandler.removeCallbacks(usageTick);
        if (homeBudget != null) homeBudget.stop();
        if (pendingFiles != null) { pendingFiles.onReceiveValue(null); pendingFiles = null; }
        closeReel();
        if (messages != null) {
            messagesSurface.removeView(messages);
            messages.destroy();
        }
        super.onDestroy();
    }
}

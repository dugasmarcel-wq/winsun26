package dev.directonly;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Pattern;

/** Checks releases of a user-configured GitHub repository; never silently installs APKs. */
public final class Updater {
    private static final Pattern REPOSITORY = Pattern.compile("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+");
    private Updater() { }

    public static void check(Activity activity, boolean interactive) {
        String repo = activity.getSharedPreferences("direct_only", 0).getString("updates_repo", "");
        if (!REPOSITORY.matcher(repo).matches()) {
            if (interactive) Toast.makeText(activity, "Set your GitHub update source in More first.", Toast.LENGTH_LONG).show();
            return;
        }
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL api = new URL("https://api.github.com/repos/" + repo + "/releases/latest");
                conn = (HttpURLConnection) api.openConnection();
                conn.setConnectTimeout(7000);
                conn.setReadTimeout(7000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("Accept", "application/vnd.github+json");
                conn.setRequestProperty("User-Agent", "DirectOnly-Android");
                if (conn.getResponseCode() != 200) throw new IllegalStateException("GitHub returned " + conn.getResponseCode());
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                try (java.io.InputStream in = conn.getInputStream()) {
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n);
                        if (out.size() > 1024 * 1024) throw new IllegalStateException("Release information too large");
                    }
                }
                JSONObject json = new JSONObject(out.toString("UTF-8"));
                String tag = json.optString("tag_name", "");
                String installed = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionName;
                if (installed == null) installed = "0.0.0";
                boolean newer = isNewer(tag, installed);
                String download = json.optString("html_url", "");
                JSONArray assets = json.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject item = assets.optJSONObject(i);
                        if (item != null && item.optString("name", "").toLowerCase().endsWith(".apk")) {
                            download = item.optString("browser_download_url", download);
                            break;
                        }
                    }
                }
                final String target = download;
                if (!target.startsWith("https://github.com/")) throw new SecurityException("Invalid update URL");
                final String description = tag;
                activity.runOnUiThread(() -> {
                    if (activity.isFinishing() || (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed())) return;
                    if (!newer) {
                        if (interactive) Toast.makeText(activity, "No newer release found.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    new AlertDialog.Builder(activity)
                            .setTitle("Direct Only update " + description)
                            .setMessage("A newer APK is available. Android will ask you to approve installation. " +
                                    "Install updates only from a GitHub repository you control and trust.")
                            .setNegativeButton("Not now", null)
                            .setPositiveButton("Open download", (d, w) -> {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(target));
                                try { activity.startActivity(intent); }
                                catch (Exception e) { Toast.makeText(activity, "No browser available.", Toast.LENGTH_LONG).show(); }
                            }).show();
                });
            } catch (Exception e) {
                if (interactive) {
                    final String msg = e.getMessage() == null ? "Unknown network error" : e.getMessage();
                    activity.runOnUiThread(() -> Toast.makeText(activity, "Update check failed: " + msg, Toast.LENGTH_LONG).show());
                }
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "DirectOnlyUpdateCheck").start();
    }

    static boolean isNewer(String incoming, String installed) {
        String[] a = clean(incoming).split("\\.");
        String[] b = clean(installed).split("\\.");
        for (int i = 0; i < Math.max(a.length, b.length); i++) {
            int x = numeric(i < a.length ? a[i] : "0");
            int y = numeric(i < b.length ? b[i] : "0");
            if (x != y) return x > y;
        }
        return false;
    }
    private static String clean(String raw) { return raw == null ? "" : raw.replaceFirst("^[vV]", "").replaceFirst("[-+].*$", ""); }
    private static int numeric(String raw) {
        try { return Integer.parseInt(raw); } catch (NumberFormatException e) { return 0; }
    }
}

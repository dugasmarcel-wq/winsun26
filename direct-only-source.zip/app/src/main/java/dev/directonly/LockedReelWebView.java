package dev.directonly;

import android.content.Context;
import android.view.MotionEvent;
import android.webkit.WebView;

/** Allow taps to play/pause, but cancel swipes before a different reel can be shown. */
public final class LockedReelWebView extends WebView {
    private float originX, originY;
    private boolean suppress;
    private final float limit;

    public LockedReelWebView(Context context) {
        super(context);
        limit = 12f * getResources().getDisplayMetrics().density;
        setVerticalScrollBarEnabled(false);
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                originX = e.getX();
                originY = e.getY();
                suppress = false;
                return super.onTouchEvent(e);
            case MotionEvent.ACTION_MOVE:
                if (!suppress && (Math.abs(e.getX() - originX) > limit ||
                        Math.abs(e.getY() - originY) > limit)) {
                    MotionEvent cancel = MotionEvent.obtain(e);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.onTouchEvent(cancel);
                    cancel.recycle();
                    suppress = true;
                }
                return suppress || super.onTouchEvent(e);
            case MotionEvent.ACTION_UP:
                if (suppress) { suppress = false; return true; }
                return super.onTouchEvent(e);
            case MotionEvent.ACTION_CANCEL:
                suppress = false;
                return super.onTouchEvent(e);
            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {
        // Reject mouse-wheel / trackpad scrolling into related Reels.
        if ((event.getSource() & android.view.InputDevice.SOURCE_CLASS_POINTER) != 0 &&
                event.getAction() == MotionEvent.ACTION_SCROLL) return true;
        return super.onGenericMotionEvent(event);
    }
}

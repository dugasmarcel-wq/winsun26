/* The native allowlist is authoritative; this JS blocks SPA navigation before URLs change. */
(function () {
  'use strict';
  if (window.__directOnlyInstalled) return;
  window.__directOnlyInstalled = true;

  function route(input) {
    try {
      const u = new URL(input, location.href);
      if (u.protocol !== 'https:' || !['instagram.com', 'www.instagram.com'].includes(u.hostname)) return 'blocked';
      const p = u.pathname;
      if (p === '/' || p === '') return 'inbox';
      if (p === '/direct' || p.startsWith('/direct/')) return 'messages';
      if (/^\/(reel|reels)\/[a-zA-Z0-9_-]+\/?$/.test(p)) return 'reel';
      if (/^\/(challenge|accounts\/(login|onetap|password|two_factor|confirm|suspended|signup))(\/|$)/.test(p)) return 'auth';
      return 'blocked';
    } catch (_) { return 'blocked'; }
  }

  function blocked() {
    try { window.DirectOnlyAndroid.blocked(); } catch (_) { /* native route is still enforced */ }
  }
  function navigate(target) {
    const type = route(target);
    if (type === 'reel' && route(location.href) === 'messages') {
      window.DirectOnlyAndroid.openReel(new URL(target, location.href).href);
      return false;
    }
    if (type === 'messages' || type === 'auth') return true;
    if (type === 'inbox') { location.replace('https://www.instagram.com/direct/inbox/'); return false; }
    blocked();
    return false;
  }

  // Capture anchor clicks before Instagram's React click handlers can run.
  document.addEventListener('click', function (event) {
    const node = event.target instanceof Element ? event.target : null;
    if (!node) return;
    const anchor = node.closest('a[href]');
    if (anchor) {
      const href = anchor.href;
      if (href && !href.startsWith('javascript:') && !href.startsWith('#') && !navigate(href)) {
        event.preventDefault(); event.stopImmediatePropagation();
      }
      return;
    }
    // Older Instagram versions implement nav items as buttons instead of anchors.
    const menuItem = node.closest('nav button, aside button, [role="navigation"] button, nav [role="button"]');
    if (menuItem) {
      const name = (menuItem.getAttribute('aria-label') || menuItem.textContent || '').trim().toLowerCase();
      if (/^(home|explore|reels|profile|create|notifications|search|more)$/.test(name)) {
        event.preventDefault(); event.stopImmediatePropagation(); blocked();
      }
    }
  }, true);

  // Instagram switches pages using the History API without WebView page loads.
  for (const method of ['pushState', 'replaceState']) {
    const original = history[method];
    history[method] = function (state, title, url) {
      if (url != null && !navigate(url)) return;
      return original.apply(this, arguments);
    };
  }
  window.addEventListener('popstate', function () {
    if (!['messages', 'auth'].includes(route(location.href))) {
      window.DirectOnlyAndroid.guardViolation();
    }
  });

  const style = document.createElement('style');
  style.textContent = [
    'nav a[href="/"], nav a[href^="/explore"], nav a[href^="/reels"],',
    'nav a[href^="/stories"], nav a[href^="/accounts/activity"],',
    'aside a[href="/"], aside a[href^="/explore"], aside a[href^="/reels"],',
    '[role="navigation"] a[href="/"], [role="navigation"] a[href^="/explore"]',
    '{display:none !important}'
  ].join(' ');
  (document.head || document.documentElement).appendChild(style);
  function hideForbiddenNavigation() {
    for (const link of document.querySelectorAll('nav a[href], aside a[href], [role="navigation"] a[href]')) {
      const r = route(link.href);
      if (!['messages', 'auth'].includes(r) && link.style.display !== 'none') link.style.display = 'none';
    }
  }
  hideForbiddenNavigation();
  new MutationObserver(hideForbiddenNavigation).observe(document.documentElement, {childList: true, subtree: true});
  if (!['messages', 'auth'].includes(route(location.href))) window.DirectOnlyAndroid.guardViolation();
})();

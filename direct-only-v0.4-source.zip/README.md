# Direct Only v0.4.0 – Galaxy S26

## Features
- Inbox remains accessible without a time limit.
- Home is accessible for a total of 5 minutes of **foreground Home viewing** each local calendar day; the allowance resets at device local midnight.
- Home time is conserved if you switch to chats, leave the app, or restart the phone. Used time is persisted at least every 250 ms while Home is foreground.
- As soon as daily Home time is exhausted, the app navigates to Instagram DMs. Home entry is disabled until the next midnight.
- Explore, unrestricted Reels, profiles, Stories, and other pages remain blocked.
- Shared Reels and enlarged DM video popups remain touch-blocked. Play/Pause and **Sound on** controls explicitly unmute the selected video.
- Retains v0.3 auto updater; release v0.4.0 uses the same Android signing key and application ID as v0.3.0.

## Important limitations
- This is an Instagram **web** wrapper, not a replacement Instagram client. Instagram website changes can cause broken navigation, unsupported DM features, or unavailable media sound.
- Device audio output/media volume must be enabled for sound. The player can force `muted = false` but cannot guarantee the stream contains audio or control Instagram's server behavior.
- The budget measures use inside Direct Only, not activity in Instagram's separate native app/browser.
- The day boundary uses the device's current local date. Moving the clock forward to another date may trigger a reset. Moving it backwards does not reset the allowance.
- Background download is automatic but Android still asks before installing a downloaded APK.

## Test plan
1. Open DMs and a video; tap **Sound on** and then **Play / Pause** as necessary.
2. Open Home from toolbar; confirm the counter decreases while scrolling the feed.
3. Switch to Inbox, wait, then return; ensure the counter does not decrease while in Inbox.
4. Force close Direct Only and reopen; ensure the previous remaining time is retained.
5. After the final 5 minutes, ensure Home returns to Inbox and Home button is disabled.
6. At local midnight, ensure Home resets to 5:00.
7. From DMs open a shared Reel; scrolling should not reveal a second Reel.

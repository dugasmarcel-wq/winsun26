# Direct Only v0.4.0 – Galaxy S26

## Features
- Inbox remains accessible without a time limit.
- Home is accessible for a total of 5 minutes of **foreground Home viewing** each local calendar day; the allowance resets at device local midnight.
- Home time is conserved if you switch to chats, leave the app, or restart the phone. Used time is persisted at least every 250 ms while Home is foreground.
- As soon as daily Home time is exhausted, the app navigates to Instagram DMs. Home entry is disabled until the next midnight.
- Explore, unrestricted Reels, profiles, Stories, and other pages remain blocked.
- Shared Reels and enlarged DM video popups remain touch-blocked. Play/Pause and **Sound on** controls explicitly unmute the selected video.
- Retains v0.3 auto updater; release v0.4.0 uses the same Android signing key and application ID as v0.3.0.

## Important limitations
- This is an Instagram **web** wrapper, not a replacement Instagram client. Instagram website changes can cause broken navigation, unsupported DM features, or unavailable media sound.
- Device audio output/media volume must be enabled for sound. The player can force `muted = false` but cannot guarantee the stream contains audio or control Instagram's server behavior.
- The budget measures use inside Direct Only, not activity in Instagram's separate native app/browser.
- The day boundary uses the device's current local date. Moving the clock forward to another date may trigger a reset. Moving it backwards does not reset the allowance.
- Background download is automatic but Android still asks before installing a downloaded APK.

## Test plan
1. Open DMs and a video; tap **Sound on** and then **Play / Pause** as necessary.
2. Open Home from toolbar; confirm the counter decreases while scrolling the feed.
3. Switch to Inbox, wait, then return; ensure the counter does not decrease while in Inbox.
4. Force close Direct Only and reopen; ensure the previous remaining time is retained.
5. After the final 5 minutes, ensure Home returns to Inbox and Home button is disabled.
6. At local midnight, ensure Home resets to 5:00.
7. From DMs open a shared Reel; scrolling should not reveal a second Reel.

## v0.5 — official Instagram launch blocker and real DM alerts

The official Instagram Android package `com.instagram.android` must remain installed
and signed in for notification forwarding. Direct Only does not request Instagram
credentials or intercept Instagram traffic.

Enable both from **More → Set up Instagram blocker + DM alerts**:

1. Android **Accessibility** → Direct Only → enable. Android notifies the
   Accessibility Service when Instagram enters the foreground; it immediately
   sends HOME and tries to launch Direct Only inbox. This is **not** a process
   force-stop. Instagram may briefly appear and it can continue receiving push
   notifications in the background. Native force-stop is impossible without
   privileged access. If sideloaded accessibility is restricted on your device,
   follow your device's restricted-settings approval flow.
2. Android **Notification access** → Direct Only → enable. On Instagram
   notifications, original notifications are dismissed (because tapping them
   would launch unrestricted Instagram). Notifications recognized as DMs are
   re-posted by Direct Only so tapping them opens its inbox instead. Instagram's
   private notification channels/formats vary; some DMs may not be classified
   correctly. Keep notification permission on for Direct Only and background
   notifications enabled for official Instagram.

The five-minute Home timer, locked Reel viewer, and signed auto-updater remain.

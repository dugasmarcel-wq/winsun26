package dev.directonly;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import java.time.LocalDate;

/** Local-midnight reset and crash-resistant foreground-only Home allowance. */
public final class HomeBudget {
    public static final long DAILY_MS = 5L * 60L * 1000L;
    private final SharedPreferences prefs;
    private boolean running;
    private long lastElapsed;

    public HomeBudget(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences("home_allowance_v1", Context.MODE_PRIVATE);
        checkDay();
    }

    private String today() { return LocalDate.now().toString(); }

    private void checkDay() {
        String saved = prefs.getString("local_day", "");
        String now = today();
        // Do not permit an extra five minutes when the device date is rolled backwards.
        if (saved.isEmpty() || now.compareTo(saved) > 0) {
            prefs.edit().putString("local_day", now).putLong("used_ms", 0L).commit();
            if (running) lastElapsed = SystemClock.elapsedRealtime();
        }
    }

    private void accrue() {
        checkDay();
        if (!running) return;
        long now = SystemClock.elapsedRealtime();
        long delta = now >= lastElapsed ? now - lastElapsed : 0;
        lastElapsed = now;
        if (delta > 0) {
            long used = Math.min(DAILY_MS, prefs.getLong("used_ms", 0L) + delta);
            prefs.edit().putLong("used_ms", used).commit();
        }
    }

    public synchronized long remainingMillis() {
        accrue();
        return Math.max(0L, DAILY_MS - prefs.getLong("used_ms", 0L));
    }
    public synchronized boolean begin() {
        if (remainingMillis() == 0L) return false;
        if (!running) { running = true; lastElapsed = SystemClock.elapsedRealtime(); }
        return true;
    }
    public synchronized void stop() { accrue(); running = false; }
    public synchronized boolean isRunning() { return running; }
}

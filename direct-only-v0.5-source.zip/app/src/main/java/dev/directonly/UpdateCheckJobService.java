package dev.directonly;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Android schedules this periodic check even when Direct Only isn't open. */
public final class UpdateCheckJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try { Updater.performCheck(this, false); }
            finally { jobFinished(params, false); }
        }, "directonly-periodic-updates").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }
}

package dev.directonly;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

/** Launches Android's package installer after the user enables installation permission. */
public final class InstallUpdateActivity extends Activity {
    private boolean installerLaunched;
    private boolean settingsLaunched;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) {
            installerLaunched = state.getBoolean("installerLaunched");
            settingsLaunched = state.getBoolean("settingsLaunched");
        }
    }
    @Override protected void onResume() {
        super.onResume();
        if (installerLaunched) { finish(); return; }
        if (!Updater.hasPending(this)) {
            Toast.makeText(this, "No verified update is available.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            if (settingsLaunched) {
                Toast.makeText(this, "Enable Install unknown apps, then tap the update notification again.", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            settingsLaunched = true;
            new AlertDialog.Builder(this)
                .setTitle("Allow Direct Only to update")
                .setMessage("Android needs permission to install APK updates. Enable 'Allow from this source' for Direct Only. Each update will still ask for installation approval.")
                .setPositiveButton("Open settings", (d,w) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Later", (d,w) -> finish()).show();
            return;
        }
        installerLaunched = true;
        Uri contentUri = Updater.contentUri(this);
        Intent installer = new Intent(Intent.ACTION_VIEW)
            .setDataAndType(contentUri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        installer.setClipData(ClipData.newRawUri("APK update", contentUri));
        try { startActivity(installer); finish(); }
        catch (Exception e) {
            Toast.makeText(this, "Unable to open Android's APK installer.", Toast.LENGTH_LONG).show();
            finish();
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("installerLaunched", installerLaunched);
        out.putBoolean("settingsLaunched", settingsLaunched);
    }
}

package dev.directonly;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

/**
 * Removes Instagram's foreground UI as soon as Android reports it.
 * This is NOT a force-stop: an ordinary third-party app cannot force-stop Instagram.
 * Android may briefly draw Instagram before delivering the accessibility event.
 */
public final class InstagramBlockService extends AccessibilityService {
    private static final String INSTAGRAM_PACKAGE = "com.instagram.android";
    private long lastBlockAt;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!INSTAGRAM_PACKAGE.contentEquals(event.getPackageName())) return;
        final int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        final long now = SystemClock.elapsedRealtime();
        if (now - lastBlockAt < 600) return;
        lastBlockAt = now;

        // HOME first, before attempting the app redirect, so that Instagram is
        // removed even on versions of Android that restrict activity starts.
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent direct = new Intent(this, MainActivity.class);
        direct.setAction(MainActivity.ACTION_SHOW_INBOX);
        direct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(direct); } catch (RuntimeException ignored) { /* HOME already sent */ }
    }

    @Override public void onInterrupt() { }
}

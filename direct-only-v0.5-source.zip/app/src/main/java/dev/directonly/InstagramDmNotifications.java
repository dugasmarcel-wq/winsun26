package dev.directonly;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;

/**
 * Notification access is required. Native Instagram notifications are dismissed
 * to avoid links that launch unrestricted Instagram. Only likely direct-message
 * notifications are reposted with an explicit Direct Only inbox PendingIntent.
 * Instagram can change its private notification channels/payloads at any time.
 */
public final class InstagramDmNotifications extends NotificationListenerService {
    private static final String INSTAGRAM = "com.instagram.android";
    private static final String CHANNEL = "directonly_instagram_messages";

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !INSTAGRAM.equals(sbn.getPackageName())) return;
        final Notification n = sbn.getNotification();
        if (n == null) return;
        final boolean dm = isDm(n);
        // The original PendingIntent would open Instagram; do not leave it tappable.
        try { cancelNotification(sbn.getKey()); } catch (SecurityException ignored) { }
        if (!dm) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Instagram direct messages",
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Instagram DM alerts that open Direct Only");
            manager.createNotificationChannel(channel);
        }
        Bundle extras = n.extras != null ? n.extras : new Bundle();
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        String safeTitle = title == null || title.length() == 0 ? "Instagram message" : title.toString();
        String safeText = text == null || text.length() == 0 ? "Open your messages" : text.toString();
        Intent open = new Intent(this, MainActivity.class);
        open.setAction(MainActivity.ACTION_SHOW_INBOX);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int id = 0x20000000 | (sbn.getKey().hashCode() & 0x0fffffff);
        PendingIntent pi = PendingIntent.getActivity(this, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.sym_action_chat)
                .setContentTitle(safeTitle)
                .setContentText(safeText)
                .setStyle(new Notification.BigTextStyle().bigText(safeText))
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        manager.notify(id, b.build());
    }

    // Conservative: never mirror arbitrary feed/live/comment notifications.
    private static boolean isDm(Notification n) {
        if (Notification.CATEGORY_MESSAGE.equals(n.category)) return true;
        Bundle ex = n.extras;
        if (ex == null) return false;
        if (ex.containsKey(Notification.EXTRA_MESSAGES) ||
                ex.containsKey(Notification.EXTRA_CONVERSATION_TITLE)) return true;
        String chan = n.getChannelId();
        if (containsDmWords(chan)) return true;
        // Wording varies by Instagram version/localization; these English hints
        // are fallbacks and cannot guarantee every DM is recognized.
        String text = String.valueOf(ex.getCharSequence(Notification.EXTRA_TEXT, ""));
        String big = String.valueOf(ex.getCharSequence(Notification.EXTRA_BIG_TEXT, ""));
        return containsDmWords(text) || containsDmWords(big) ||
                text.toLowerCase(Locale.ROOT).contains("sent you") ||
                text.toLowerCase(Locale.ROOT).contains("replied to your message") ||
                text.toLowerCase(Locale.ROOT).contains("shared a reel");
    }

    private static boolean containsDmWords(String raw) {
        if (raw == null) return false;
        String s = raw.toLowerCase(Locale.ROOT);
        return s.contains("direct") || s.contains("dm_") || s.contains("_dm") ||
                s.contains("message") || s.contains("chat") || s.contains("inbox");
    }
}

package dev.directonly;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** First-party, no-configuration GitHub Releases updater. Never installs an APK silently. */
public final class Updater {
    static final String APK_FILE = "directonly-update.apk";
    private static final String REPO = "dugasmarcel-wq/winsun26";
    private static final String API = "https://api.github.com/repos/" + REPO + "/releases?per_page=30";
    private static final String PREFIX = "directonly-v";
    private static final String CHANNEL = "directonly_updates";
    private static final int NOTIFICATION_ID = 7311;
    private static final int JOB_ID = 730031;
    private static final long CHECK_INTERVAL = 12L * 60 * 60 * 1000;
    private static final long MAX_APK_BYTES = 120L * 1024 * 1024;
    private static final AtomicBoolean ACTIVE = new AtomicBoolean(false);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static boolean promptedThisSession;

    private Updater() { }

    public static void register(Context context) {
        try {
            JobScheduler jobs = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (jobs == null || jobs.getPendingJob(JOB_ID) != null) return;
            JobInfo job = new JobInfo.Builder(JOB_ID,
                    new ComponentName(context, UpdateCheckJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(CHECK_INTERVAL)
                .build();
            jobs.schedule(job);
        } catch (RuntimeException ignored) { }
    }

    public static void check(Context context, boolean interactive) {
        Context app = context.getApplicationContext();
        // Automatic checks happen on start and in the background, but no more than once per hour.
        if (!interactive && System.currentTimeMillis() - app.getSharedPreferences("updates", 0)
                .getLong("last_check", 0) < 3600000L) return;
        new Thread(() -> performCheck(interactive && context instanceof Activity ? context : app, interactive),
                "directonly-update-check").start();
    }

    public static void performCheck(Context context, boolean interactive) {
        if (!ACTIVE.compareAndSet(false, true)) return;
        HttpURLConnection conn = null;
        try {
            conn = connect(API, "application/vnd.github+json");
            JSONArray list = new JSONArray(readLimited(conn.getInputStream(), 2L * 1024 * 1024));
            JSONObject latest = null, asset = null;
            int[] best = new int[]{0,0,0};
            for (int i = 0; i < list.length(); i++) {
                JSONObject release = list.optJSONObject(i);
                if (release == null || release.optBoolean("draft") || release.optBoolean("prerelease")) continue;
                String tag = release.optString("tag_name", "");
                if (!tag.startsWith(PREFIX)) continue;
                int[] version = parseVersion(tag.substring(PREFIX.length()));
                if (version == null || compareVersions(version, best) <= 0) continue;
                JSONArray assets = release.optJSONArray("assets");
                if (assets == null) continue;
                for (int j = 0; j < assets.length(); j++) {
                    JSONObject a = assets.optJSONObject(j);
                    if (a != null && a.optString("name", "").matches("DirectOnly-S26-v[0-9.]+\\.apk") &&
                            a.optString("browser_download_url", "").startsWith("https://github.com/" + REPO + "/releases/download/")) {
                        latest = release; asset = a; best = version; break;
                    }
                }
            }
            context.getSharedPreferences("updates", 0).edit()
                .putLong("last_check", System.currentTimeMillis()).apply();
            if (latest == null) throw new IllegalStateException("No Direct Only release published yet");
            int[] installed = parseVersion(installedVersion(context));
            if (installed == null) installed = new int[]{0,0,0};
            if (compareVersions(best, installed) <= 0) {
                clearStale(context);
                if (interactive) toast(context, "Direct Only is up to date (" + installedVersion(context) + ").");
                return;
            }
            String pendingVersion = latest.optString("tag_name", "").substring(PREFIX.length());
            if (pendingVersion.equals(context.getSharedPreferences("updates", 0).getString("pending_version", ""))
                    && hasPending(context)) {
                if (interactive) promptInstall(context);
                else notifyUpdate(context, pendingVersion);
                return;
            }
            String url = asset.getString("browser_download_url");
            String sha = asset.optString("digest", "");
            downloadAndVerify(context, url, pendingVersion, sha);
            notifyUpdate(context, pendingVersion);
            if (interactive) promptInstall(context);
        } catch (Exception e) {
            if (interactive) toast(context, "Update check failed: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
            ACTIVE.set(false);
        }
    }

    private static void downloadAndVerify(Context context, String url, String version, String digest) throws Exception {
        File temp = new File(context.getFilesDir(), "directonly-update.tmp");
        File apk = new File(context.getFilesDir(), APK_FILE);
        temp.delete();
        HttpURLConnection connection = null;
        try {
            connection = connect(url, "application/octet-stream");
            long length = connection.getContentLengthLong();
            if (length > MAX_APK_BYTES) throw new IllegalStateException("APK exceeds size limit");
            MessageDigest hasher = MessageDigest.getInstance("SHA-256");
            long total = 0;
            try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(temp)) {
                byte[] buf = new byte[16384]; int n;
                while ((n = input.read(buf)) != -1) {
                    total += n;
                    if (total > MAX_APK_BYTES) throw new IllegalStateException("APK exceeds size limit");
                    output.write(buf, 0, n);
                    hasher.update(buf, 0, n);
                }
                output.getFD().sync();
            }
            if (total < 4096) throw new IllegalStateException("Incomplete APK");
            if (digest.startsWith("sha256:") && !toHex(hasher.digest()).equalsIgnoreCase(digest.substring(7)))
                throw new IllegalStateException("APK checksum mismatch");
            if (!verifyArchive(context, temp, version)) throw new IllegalStateException("APK package or signature mismatch");
            if (apk.exists() && !apk.delete()) throw new IllegalStateException("Cannot replace prior update");
            if (!temp.renameTo(apk)) throw new IllegalStateException("Cannot save update");
            context.getSharedPreferences("updates", 0).edit().putString("pending_version", version).apply();
        } finally {
            if (connection != null) connection.disconnect();
            temp.delete();
        }
    }

    private static boolean verifyArchive(Context context, File apk, String version) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo incoming = pm.getPackageArchiveInfo(apk.getAbsolutePath(),
                    PackageManager.GET_SIGNING_CERTIFICATES);
            PackageInfo current = pm.getPackageInfo(context.getPackageName(),
                    PackageManager.GET_SIGNING_CERTIFICATES);
            if (incoming == null || !context.getPackageName().equals(incoming.packageName)) return false;
            if (!version.equals(incoming.versionName)) return false;
            if (incoming.getLongVersionCode() <= current.getLongVersionCode()) return false;
            Signature[] a = incoming.signingInfo == null ? null : incoming.signingInfo.getApkContentsSigners();
            Signature[] b = current.signingInfo == null ? null : current.signingInfo.getApkContentsSigners();
            return a != null && b != null && a.length == 1 && b.length == 1 && Arrays.equals(a[0].toByteArray(), b[0].toByteArray());
        } catch (Exception e) { return false; }
    }

    public static boolean hasPending(Context context) {
        File f = new File(context.getFilesDir(), APK_FILE);
        String v = context.getSharedPreferences("updates", 0).getString("pending_version", "");
        return f.length() > 0 && !v.isEmpty() && verifyArchive(context, f, v);
    }

    public static Uri contentUri(Context context) {
        return new Uri.Builder().scheme("content")
            .authority(context.getPackageName() + ".updates")
            .appendPath("update.apk").build();
    }

    public static void promptInstall(Context context) {
        if (!(context instanceof Activity)) return;
        Activity activity = (Activity) context;
        MAIN.post(() -> {
            if (activity.isFinishing() || activity.isDestroyed() || !hasPending(activity)) return;
            new AlertDialog.Builder(activity).setTitle("Update downloaded")
                .setMessage("Direct Only " + activity.getSharedPreferences("updates", 0).getString("pending_version", "") +
                        " is ready. Android will ask you to approve installation.")
                .setPositiveButton("Install", (d,w) -> activity.startActivity(new Intent(activity, InstallUpdateActivity.class)))
                .setNegativeButton("Later", null).show();
        });
    }

    public static void maybePromptOnResume(Activity activity) {
        if (!promptedThisSession && hasPending(activity)) {
            promptedThisSession = true;
            promptInstall(activity);
        }
    }

    private static void notifyUpdate(Context context, String version) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Direct Only updates", NotificationManager.IMPORTANCE_DEFAULT));
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        Intent action = new Intent(context, InstallUpdateActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, NOTIFICATION_ID, action,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Direct Only " + version + " ready")
            .setContentText("Downloaded automatically. Tap to install.")
            .setContentIntent(pending)
            .setAutoCancel(true).build();
        nm.notify(NOTIFICATION_ID, notification);
    }

    private static void clearStale(Context context) {
        new File(context.getFilesDir(), APK_FILE).delete();
        context.getSharedPreferences("updates", 0).edit().remove("pending_version").apply();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
    }

    private static HttpURLConnection connect(String target, String accept) throws Exception {
        URL url = new URL(target);
        for (int redirects = 0; redirects < 6; redirects++) {
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !isTrustedHost(url.getHost()))
                throw new IllegalStateException("Untrusted download host");
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", "DirectOnly-Android/0.4");
            c.setRequestProperty("Accept", accept);
            int status = c.getResponseCode();
            if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                String next = c.getHeaderField("Location");
                c.disconnect();
                if (next == null) throw new IllegalStateException("Missing redirect URL");
                url = new URL(url, next);
                continue;
            }
            if (status != 200) {
                c.disconnect();
                throw new IllegalStateException("Download returned HTTP " + status);
            }
            return c;
        }
        throw new IllegalStateException("Too many redirects");
    }

    private static boolean isTrustedHost(String host) {
        return "github.com".equalsIgnoreCase(host) || "api.github.com".equalsIgnoreCase(host)
            || "release-assets.githubusercontent.com".equalsIgnoreCase(host)
            || "objects.githubusercontent.com".equalsIgnoreCase(host);
    }

    private static String readLimited(InputStream input, long max) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = input) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) {
                if ((long) out.size() + n > max) throw new IllegalStateException("Update metadata too large");
                out.write(buf, 0, n);
            }
        }
        return out.toString("UTF-8");
    }

    private static String installedVersion(Context context) {
        try { return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName; }
        catch (Exception e) { return "0.0.0"; }
    }

    static int[] parseVersion(String s) {
        if (s == null || !s.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) return null;
        String[] p = s.split("\\.");
        try { return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])}; }
        catch (NumberFormatException e) { return null; }
    }
    static int compareVersions(int[] a, int[] b) {
        for (int i = 0; i < 3; i++) if (a[i] != b[i]) return Integer.compare(a[i], b[i]);
        return 0;
    }
    private static String toHex(byte[] bytes) {
        StringBuilder b = new StringBuilder(bytes.length * 2);
        for (byte v : bytes) b.append(String.format(Locale.ROOT, "%02x", v & 0xff));
        return b.toString();
    }
    private static void toast(Context c, String message) {
        MAIN.post(() -> Toast.makeText(c, message, Toast.LENGTH_LONG).show());
    }
}

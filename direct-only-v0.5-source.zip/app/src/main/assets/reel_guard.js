/* Reel page: only the exact shared shortcode can be displayed; scrolling is forbidden. */
(function () {
  'use strict';
  if (window.__directOnlyReelInstalled) return;
  window.__directOnlyReelInstalled = true;
  const id = '__DIRECT_ONLY_REEL_ID__';
  const allowed = u => {
    try {
      const parsed = new URL(u, location.href);
      return parsed.protocol === 'https:' && ['instagram.com', 'www.instagram.com'].includes(parsed.hostname) &&
        ['/reel/' + id, '/reel/' + id + '/', '/reels/' + id, '/reels/' + id + '/'].includes(parsed.pathname);
    } catch (_) { return false; }
  };
  const block = e => { e.preventDefault(); e.stopImmediatePropagation(); };
  let selected = null;
  let selectedSrc = '';
  function locatePlayer() {
    if (selected && selected.isConnected) return selected;
    const candidates = Array.from(document.querySelectorAll('video')).filter(v => {
      const box = v.getBoundingClientRect();
      return box.width > 30 && box.height > 30;
    });
    if (!selected && candidates.length) selected = candidates[0];
    return selected;
  }
  window.DirectOnlyReel = {
    enableSound: function () {
      const v = locatePlayer();
      if (v) {
        v.muted = false;
        v.defaultMuted = false;
        v.removeAttribute('muted');
        v.volume = 1;
      }
    },
    togglePlayback: function () {
      const v = locatePlayer();
      if (!v) return;
      this.enableSound();
      if (v.paused) v.play().catch(() => {});
      else v.pause();
    }
  };
  function enforce() {
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    if (document.body) document.body.style.setProperty('overflow', 'hidden', 'important');
    if (window.scrollX || window.scrollY) window.scrollTo(0, 0);
    const playing = locatePlayer();
    if (playing) {
      const url = playing.currentSrc || playing.src;
      if (url && !selectedSrc) selectedSrc = url;
      // Once pinned to a video, refuse automatic progression to another source.
      if (selectedSrc && url && url !== selectedSrc) {
        playing.pause();
        playing.style.setProperty('visibility', 'hidden', 'important');
      }
    }
    for (const v of document.querySelectorAll('video')) {
      if (v !== playing) {
        v.pause();
        if (v.style.display !== 'none') v.style.display = 'none';
      }
    }
    // Hide recommendation links, but not the player and its video controls.
    for (const a of document.querySelectorAll('a[href]')) {
      if (!allowed(a.href) && a.style.pointerEvents !== 'none') a.style.pointerEvents = 'none';
    }
  }
  document.addEventListener('click', e => {
    const a = e.target instanceof Element && e.target.closest('a[href]');
    if (a && !allowed(a.href)) block(e);
    const b = e.target instanceof Element && e.target.closest('button,[role="button"]');
    if (b && /^(next|previous|reels|explore|home|more)$/i.test((b.getAttribute('aria-label') || '').trim())) block(e);
  }, true);
  // No vertical/horizontal swipe gestures, wheel scrolling, or keyboard next navigation.
  for (const name of ['touchmove', 'wheel']) document.addEventListener(name, block, {capture: true, passive: false});
  document.addEventListener('keydown', e => {
    if (['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','PageDown','PageUp',' '].includes(e.key) &&
        !(e.target instanceof Element && e.target.closest('textarea,input,[contenteditable="true"]'))) block(e);
  }, true);
  for (const method of ['pushState', 'replaceState']) {
    const original = history[method];
    history[method] = function (state, title, url) {
      if (url != null && !allowed(url)) return;
      return original.apply(this, arguments);
    };
  }
  document.addEventListener('ended', event => {
    if (event.target === selected) {
      selected.pause();
      try { selected.currentTime = 0; } catch (_) {}
    }
  }, true);
  enforce();
  new MutationObserver(enforce).observe(document.documentElement, {childList: true, subtree: true});
  setInterval(enforce, 600);
})();

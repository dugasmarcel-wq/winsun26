#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
javac -d "$workdir" app/src/main/java/dev/directonly/UrlPolicy.java tests/UrlPolicyTest.java
java -cp "$workdir" UrlPolicyTest

# Direct Only v0.3.0 – Galaxy S26

An Android WebView app that keeps Instagram Direct Messages accessible while blocking navigation to the Instagram home feed, Explore, profiles and scrolling to other Reels. Instagram can change behavior; limits have not been confirmed on a physical S26.

## Automatic updates

- No configuration. The app checks releases tagged `directonly-v*` from `dugasmarcel-wq/winsun26` when opened and using Android's periodic network JobScheduler (roughly twice daily, subject to power management).
- When a newer version is available, it downloads the APK automatically to private storage, compares the published SHA-256 digest when GitHub provides one, checks package ID, signing certificate and version, then posts a notification with an install prompt. On Android 13+, enable notification permission when asked to receive background notices.
- On the notification, tap to approve installation. Android *does not allow* a normal sideloaded app to silently install its own update.
- More > Check for updates checks instantly. More > Install downloaded update reopens the installer.
- v0.3.0 is the first stable-signing release and uses package `dev.directonly.debug`, the same ID as older debug APKs. **Because the old debug APK was signed with a temporary key, uninstall it once before installing v0.3.0.** Future signed versions can update v0.3.0 without uninstalling, provided the same signing key is retained.

## Signing key caveat

The dedicated GitHub Actions build branch keeps the signing key in the GitHub Actions cache, not in the public source. **Actions cache entries can expire after inactivity (typically 7 days)**. If it expires, the signing key will be lost and later APKs won't update installed copies. For permanent reliable updates, a private release signing key must be stored as a GitHub Actions repository secret and reused by future builds. A key cache is temporary infrastructure, not a substitute for a secret-backed release pipeline.

## Limitations

The app uses Instagram's mobile website. Native message notifications, calls, some media handling and login flows may differ from Instagram. Media swipe restrictions are not verified against the current Instagram website on an S26. The app doesn't block the separate native Instagram installation.

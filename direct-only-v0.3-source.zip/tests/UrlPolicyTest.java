import dev.directonly.UrlPolicy;
import static dev.directonly.UrlPolicy.Destination.*;

public class UrlPolicyTest {
    private static int count = 0;
    private static void expect(String link, UrlPolicy.Destination expected) {
        UrlPolicy.Destination actual = UrlPolicy.classify(link);
        if (actual != expected) throw new AssertionError(link + " expected " + expected + ", got " + actual);
        count++;
    }
    public static void main(String[] args) {
        expect(UrlPolicy.INBOX, MESSAGES);
        expect("https://instagram.com/direct/t/12345/?foo=1", MESSAGES);
        expect("https://www.instagram.com/direct/requests/", MESSAGES);
        expect("https://instagram.com/accounts/login/", LOGIN);
        expect("https://instagram.com/challenge/987/", LOGIN);
        expect("https://instagram.com/", INBOX_REDIRECT);
        expect("https://instagram.com/reel/Abc123XYZ/?utm_source=ig", SINGLE_REEL);
        expect("https://www.instagram.com/reels/Abc123XYZ/", SINGLE_REEL);
        expect("https://instagram.com/reels/", BLOCKED);
        expect("https://instagram.com/reel/Abc+123/", BLOCKED);
        expect("https://instagram.com/explore/", BLOCKED);
        expect("https://instagram.com/stories/someone/123", BLOCKED);
        expect("https://instagram.com/some_person/", BLOCKED);
        expect("https://instagram.com/p/Abc123/", BLOCKED);
        expect("https://instagram.com/accounts/activity/", BLOCKED);
        expect("https://www.instagram.com.evil.com/direct/inbox/", BLOCKED);
        expect("http://www.instagram.com/direct/inbox/", BLOCKED);
        expect("javascript:alert('x')", BLOCKED);
        expect("https://google.com/direct/inbox/", BLOCKED);
        expect("https://instagram.com@evil.com/direct/inbox", BLOCKED);
        if (!UrlPolicy.sameReel("https://instagram.com/reel/ABC123/", "https://instagram.com/reels/ABC123/?x=1")) throw new AssertionError("reel equality");
        if (UrlPolicy.sameReel("https://instagram.com/reel/ABC123/", "https://instagram.com/reel/NEXT/")) throw new AssertionError("reel navigation");
        System.out.println("Passed " + count + " route-security checks + 2 reel checks.");
    }
}

package dev.directonly;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** DM-only wrapper for instagram.com. No Instagram passwords or messages are read by this app. */
public final class MainActivity extends Activity {
    private static final int REQUEST_PICK_FILE = 1438;
    private final int black = Color.rgb(18, 18, 18);
    private final int grey = Color.rgb(190, 190, 190);
    private FrameLayout root;
    private LinearLayout messagesSurface;
    private LinearLayout reelSurface;
    private FrameLayout inboxFrame;
    private FrameLayout inlineShield;
    private WebView messages;
    private LockedReelWebView reel;
    private String activeReel;
    private ValueCallback<Uri[]> pendingFiles;
    private String inboxScript;
    private String reelScript;
    private boolean exiting;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(black);
        getWindow().setNavigationBarColor(black);
        inboxScript = readAsset("direct_guard.js");
        reelScript = readAsset("reel_guard.js");
        buildUi();
        messages.loadUrl(UrlPolicy.INBOX);
        Updater.register(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 733);
        }
        Updater.check(this, false);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(black);
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            root.setPadding(0, top, 0, bottom);
            return insets;
        });
        messagesSurface = new LinearLayout(this);
        messagesSurface.setOrientation(LinearLayout.VERTICAL);
        messagesSurface.setBackgroundColor(black);
        root.addView(messagesSurface, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout toolbar = toolbar();
        TextView title = label("DIRECT ONLY", 15, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        toolbar.addView(button("Inbox", v -> messages.loadUrl(UrlPolicy.INBOX)));
        toolbar.addView(button("Reload", v -> messages.reload()));
        toolbar.addView(button("More", v -> showMenu()));
        messagesSurface.addView(toolbar);

        messages = new WebView(this);
        configureWebView(messages);
        messages.addJavascriptInterface(new InboxBridge(), "DirectOnlyAndroid");
        messages.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return decideInboxNavigation(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return decideInboxNavigation(url);
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (inlineShield != null) inlineShield.setVisibility(View.GONE);
                UrlPolicy.Destination d = UrlPolicy.classify(url);
                if (d == UrlPolicy.Destination.INBOX_REDIRECT || d == UrlPolicy.Destination.BLOCKED ||
                        d == UrlPolicy.Destination.SINGLE_REEL) {
                    view.stopLoading();
                    if (d == UrlPolicy.Destination.SINGLE_REEL) showSingleReel(url);
                    else if (d == UrlPolicy.Destination.BLOCKED) notifyBlocked();
                    view.post(() -> view.loadUrl(UrlPolicy.INBOX));
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (UrlPolicy.classify(url) == UrlPolicy.Destination.MESSAGES ||
                        UrlPolicy.classify(url) == UrlPolicy.Destination.LOGIN) {
                    view.evaluateJavascript(inboxScript, null);
                }
            }
        });
        messages.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = cb;
                Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("*/*");
                picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(picker, "Select message attachment"), REQUEST_PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFiles.onReceiveValue(null);
                    pendingFiles = null;
                    return false;
                }
            }
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                                                    boolean isUserGesture, android.os.Message resultMsg) {
                notifyBlocked();
                return false;
            }
        });
        inboxFrame = new FrameLayout(this);
        inboxFrame.addView(messages, new FrameLayout.LayoutParams(-1, -1));

        // The native layer consumes ALL touches in Instagram's inline media popup,
        // regardless of whether that popup changes the browser URL.
        inlineShield = new FrameLayout(this);
        inlineShield.setVisibility(View.GONE);
        inlineShield.addView(blockingGlass(), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout mediaBar = toolbar();
        mediaBar.addView(button("Back to chat", v -> {
            inlineShield.setVisibility(View.GONE);
            String chat = messages.getUrl();
            messages.loadUrl(UrlPolicy.classify(chat) == UrlPolicy.Destination.MESSAGES
                    ? chat : UrlPolicy.INBOX);
        }));
        mediaBar.addView(button("Play / Pause", v -> messages.evaluateJavascript(
                "window.DirectOnlyInline&&window.DirectOnlyInline.togglePlayback()", null)));
        FrameLayout.LayoutParams barPosition = new FrameLayout.LayoutParams(-1, dp(58), Gravity.BOTTOM);
        inlineShield.addView(mediaBar, barPosition);
        inboxFrame.addView(inlineShield, new FrameLayout.LayoutParams(-1, -1));
        messagesSurface.addView(inboxFrame, new LinearLayout.LayoutParams(-1, 0, 1));

        reelSurface = new LinearLayout(this);
        reelSurface.setOrientation(LinearLayout.VERTICAL);
        reelSurface.setBackgroundColor(black);
        reelSurface.setVisibility(View.GONE);
        root.addView(reelSurface, new FrameLayout.LayoutParams(-1, -1));
    }

    private void configureWebView(WebView web) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // needed for user-selected DM attachments
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setBackgroundColor(Color.WHITE);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private boolean decideInboxNavigation(String url) {
        UrlPolicy.Destination dest = UrlPolicy.classify(url);
        if (dest == UrlPolicy.Destination.MESSAGES || dest == UrlPolicy.Destination.LOGIN) return false;
        if (dest == UrlPolicy.Destination.SINGLE_REEL) {
            if (UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.MESSAGES) showSingleReel(url);
            else notifyBlocked();
        } else if (dest == UrlPolicy.Destination.INBOX_REDIRECT) {
            messages.post(() -> messages.loadUrl(UrlPolicy.INBOX));
        } else {
            notifyBlocked();
        }
        return true;
    }

    private void showSingleReel(String url) {
        if (UrlPolicy.classify(url) != UrlPolicy.Destination.SINGLE_REEL) return;
        if (reel != null) closeReel();
        activeReel = url;
        reelSurface.removeAllViews();
        LinearLayout toolbar = toolbar();
        toolbar.addView(button("Back to messages", v -> closeReel()));
        toolbar.addView(button("Play / Pause", v -> {
            if (reel != null) reel.evaluateJavascript(
                    "window.DirectOnlyReel&&window.DirectOnlyReel.togglePlayback()", null);
        }));
        TextView hint = label("One Reel only", 12, grey);
        toolbar.addView(hint, new LinearLayout.LayoutParams(0, dp(52), 1));
        reelSurface.addView(toolbar);

        reel = new LockedReelWebView(this);
        configureWebView(reel);
        // A native button controls playback, because the Instagram document has no touch access.
        reel.getSettings().setMediaPlaybackRequiresUserGesture(false);
        reel.setBackgroundColor(Color.BLACK);
        reel.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return request.isForMainFrame() && rejectReelNavigation(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return rejectReelNavigation(url);
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                if (!UrlPolicy.sameReel(activeReel, url)) {
                    view.stopLoading();
                    notifyBlocked();
                    closeReel();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (UrlPolicy.sameReel(activeReel, url)) {
                    String locked = reelScript.replace("__DIRECT_ONLY_REEL_ID__", UrlPolicy.reelId(activeReel));
                    view.evaluateJavascript(locked, null);
                }
            }
        });
        reel.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean dialog,
                                                    boolean gesture, android.os.Message msg) {
                notifyBlocked();
                return false;
            }
        });
        FrameLayout lockedFrame = new FrameLayout(this);
        lockedFrame.addView(reel, new FrameLayout.LayoutParams(-1, -1));
        lockedFrame.addView(blockingGlass(), new FrameLayout.LayoutParams(-1, -1));
        reelSurface.addView(lockedFrame, new LinearLayout.LayoutParams(-1, 0, 1));
        reelSurface.setVisibility(View.VISIBLE);
        reel.loadUrl(url);
    }

    private boolean rejectReelNavigation(String url) {
        if (UrlPolicy.sameReel(activeReel, url)) return false;
        notifyBlocked();
        return true;
    }

    private void closeReel() {
        if (reel == null) return;
        reelSurface.setVisibility(View.GONE);
        reel.stopLoading();
        reel.loadUrl("about:blank");
        ViewGroup parent = (ViewGroup) reel.getParent();
        if (parent != null) parent.removeView(reel);
        reelSurface.removeAllViews();
        reel.destroy();
        reel = null;
        activeReel = null;
    }

    /** Native input interception: Instagram cannot see taps, swipes, or carousel controls. */
    private View blockingGlass() {
        View glass = new View(this);
        glass.setClickable(true);
        glass.setOnTouchListener((v, event) -> true);
        glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return glass;
    }

    private class InboxBridge {
        @JavascriptInterface
        public void openReel(String url) {
            runOnUiThread(() -> {
                if (UrlPolicy.classify(messages.getUrl()) == UrlPolicy.Destination.MESSAGES &&
                        UrlPolicy.classify(url) == UrlPolicy.Destination.SINGLE_REEL) showSingleReel(url);
                else notifyBlocked();
            });
        }
        @JavascriptInterface
        public void setInlineVideoOpen(boolean isOpen) {
            runOnUiThread(() -> {
                if (inlineShield != null && reel == null) {
                    inlineShield.setVisibility(isOpen ? View.VISIBLE : View.GONE);
                }
            });
        }
        @JavascriptInterface
        public void blocked() { runOnUiThread(() -> notifyBlocked()); }
        @JavascriptInterface
        public void guardViolation() {
            runOnUiThread(() -> {
                if (UrlPolicy.classify(messages.getUrl()) != UrlPolicy.Destination.MESSAGES &&
                        UrlPolicy.classify(messages.getUrl()) != UrlPolicy.Destination.LOGIN) {
                    messages.loadUrl(UrlPolicy.INBOX);
                }
            });
        }
    }

    private void showMenu() {
        new AlertDialog.Builder(this)
            .setTitle("Direct Only")
            .setItems(new String[]{"Check for updates", "Install downloaded update", "Restrictions / privacy"},
                (dialog, which) -> {
                    if (which == 0) Updater.check(this, true);
                    if (which == 1) {
                        if (Updater.hasPending(this)) startActivity(new Intent(this, InstallUpdateActivity.class));
                        else Toast.makeText(this, "No verified update has been downloaded yet.", Toast.LENGTH_LONG).show();
                    }
                    if (which == 2) new AlertDialog.Builder(this)
                        .setTitle("DM-only rules")
                        .setMessage("Only messages and specifically shared Reels are accessible. " +
                            "Instagram's website may change and interfere with blocking. " +
                            "Updates are checked automatically and downloaded from the Direct Only GitHub Releases feed. " +
                            "Android must approve each APK installation.")
                        .setPositiveButton("OK", null).show();
                }).show();
    }

    @Override protected void onResume() {
        super.onResume();
        Updater.maybePromptOnResume(this);
    }

    private void notifyBlocked() {
        if (!exiting) Toast.makeText(this, "Blocked. Only messages and shared Reels are available.", Toast.LENGTH_SHORT).show();
    }

    private LinearLayout toolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setBackgroundColor(black);
        t.setPadding(dp(12), 0, dp(7), 0);
        t.setMinimumHeight(dp(52));
        return t;
    }

    private Button button(String name, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(name);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(47, 47, 47)));
        b.setOnClickListener(click);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private TextView label(String text, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) { throw new IllegalStateException("Missing required guard: " + name, e); }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_PICK_FILE || pendingFiles == null) return;
        Uri[] resultUris = null;
        if (result == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                android.content.ClipData clip = data.getClipData();
                resultUris = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) resultUris[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                resultUris = new Uri[]{data.getData()};
            }
        }
        pendingFiles.onReceiveValue(resultUris);
        pendingFiles = null;
    }

    @Override
    public void onBackPressed() {
        if (reel != null) { closeReel(); return; }
        if (messages != null && messages.canGoBack()) { messages.goBack(); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        exiting = true;
        if (pendingFiles != null) { pendingFiles.onReceiveValue(null); pendingFiles = null; }
        closeReel();
        if (messages != null) {
            messagesSurface.removeView(messages);
            messages.destroy();
        }
        super.onDestroy();
    }
}

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
javac -d "$workdir" app/src/main/java/dev/directonly/ShortsSignals.java tests/ShortsSignalsTest.java
java -cp "$workdir" ShortsSignalsTest

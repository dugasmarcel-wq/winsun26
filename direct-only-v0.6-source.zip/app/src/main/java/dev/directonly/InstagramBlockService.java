package dev.directonly;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayDeque;
import java.util.List;

/**
 * Removes official Instagram from the foreground and blocks YouTube Shorts.
 * This is an accessibility-based navigation block, not a true process force-stop.
 * YouTube's normal video player, search, subscriptions and Home remain usable.
 * No accessibility data is stored or transmitted.
 */
public final class InstagramBlockService extends AccessibilityService {
    private static final String INSTAGRAM_PACKAGE = "com.instagram.android";
    private static final String YOUTUBE_PACKAGE = "com.google.android.youtube";
    private static final long INSTAGRAM_COOLDOWN_MS = 600;
    private static final long SHORTS_ACTION_COOLDOWN_MS = 650;
    private static final long TREE_SCAN_COOLDOWN_MS = 180;
    private static final int MAX_TREE_NODES = 350;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastInstagramBlockAt;
    private long lastShortsBlockAt;
    private long lastTreeScanAt;
    private int consecutiveShortsBacks;
    private long lastYoutubeEventAt;
    private final Runnable verifyShorts = this::checkShortsTree;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        int type = event.getEventType();
        if (INSTAGRAM_PACKAGE.equals(pkg)) {
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                    type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) blockInstagram();
            return;
        }
        if (!YOUTUBE_PACKAGE.equals(pkg)) return;
        lastYoutubeEventAt = SystemClock.elapsedRealtime();

        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            AccessibilityNodeInfo source = event.getSource();
            try {
                if (clickedShorts(source, event.getText())) {
                    blockShorts();
                    return;
                }
            } finally {
                if (source != null) source.recycle();
            }
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (ShortsSignals.playerWindow(event.getClassName())) {
                blockShorts();
                return;
            }
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
                type == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTreeScanAt >= TREE_SCAN_COOLDOWN_MS) {
                lastTreeScanAt = now;
                checkShortsTree();
            }
        }
    }

    private boolean clickedShorts(AccessibilityNodeInfo node, List<CharSequence> eventText) {
        if (node != null && ShortsSignals.shortsClick(node.getText(),
                node.getContentDescription(), node.getViewIdResourceName())) return true;
        if (eventText != null) {
            for (CharSequence value : eventText) {
                if (ShortsSignals.shortsClick(value, null, null)) return true;
            }
        }
        return false;
    }

    private void checkShortsTree() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null ||
                !YOUTUBE_PACKAGE.contentEquals(root.getPackageName())) {
            if (root != null) root.recycle();
            return;
        }
        boolean found = false;
        ArrayDeque<AccessibilityNodeInfo> stack = new ArrayDeque<>();
        stack.push(root);
        int count = 0;
        while (!stack.isEmpty() && ++count <= MAX_TREE_NODES) {
            AccessibilityNodeInfo node = stack.pop();
            try {
                if (ShortsSignals.playerMarker(node.getViewIdResourceName(),
                        node.getContentDescription()) ||
                        ShortsSignals.playerWindow(node.getClassName())) {
                    found = true;
                    break;
                }
                for (int i = 0; i < node.getChildCount(); i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null) stack.push(child);
                }
            } finally { node.recycle(); }
        }
        while (!stack.isEmpty()) stack.pop().recycle();
        if (found) blockShorts();
        else if (SystemClock.elapsedRealtime() - lastShortsBlockAt > 1800) consecutiveShortsBacks = 0;
    }

    private void blockShorts() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastShortsBlockAt < SHORTS_ACTION_COOLDOWN_MS) return;
        consecutiveShortsBacks = now - lastShortsBlockAt < 2700 ? consecutiveShortsBacks + 1 : 1;
        lastShortsBlockAt = now;
        if (consecutiveShortsBacks > 3) {
            // Guard against being trapped in a Shorts UI that ignores Back.
            performGlobalAction(GLOBAL_ACTION_HOME);
            consecutiveShortsBacks = 0;
            return;
        }
        performGlobalAction(GLOBAL_ACTION_BACK);
        // Some versions of YouTube display a second Shorts surface after Back.
        handler.removeCallbacks(verifyShorts);
        handler.postDelayed(verifyShorts, 750);
    }

    private void blockInstagram() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastInstagramBlockAt < INSTAGRAM_COOLDOWN_MS) return;
        lastInstagramBlockAt = now;
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent direct = new Intent(this, MainActivity.class);
        direct.setAction(MainActivity.ACTION_SHOW_INBOX);
        direct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(direct); } catch (RuntimeException ignored) { }
    }

    @Override public void onInterrupt() { handler.removeCallbacks(verifyShorts); }
    @Override public void onDestroy() { handler.removeCallbacks(verifyShorts); super.onDestroy(); }
}

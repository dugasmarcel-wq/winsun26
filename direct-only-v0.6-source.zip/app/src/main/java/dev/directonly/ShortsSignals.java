package dev.directonly;

import java.util.Locale;

/**
 * Small, Android-independent YouTube Shorts recognizer.
 * Deliberately never infers a Shorts player from a generic "Shorts" label on
 * the YouTube Home screen or from the standard Like/Share video controls.
 */
public final class ShortsSignals {
    private ShortsSignals() { }

    private static String norm(CharSequence text) {
        return text == null ? "" : text.toString().toLowerCase(Locale.ROOT).trim();
    }

    /** Navigation: a user actually activated the Shorts control, not merely saw it. */
    public static boolean shortsClick(CharSequence text, CharSequence description, CharSequence viewId) {
        String t = norm(text), d = norm(description), id = norm(viewId);
        if (t.equals("shorts") || t.equals("youtube shorts") || d.equals("shorts") ||
                d.equals("shorts tab") || d.equals("shorts, tab") ||
                d.equals("shorts, selected") || d.equals("shorts, not selected") ||
                d.equals("youtube shorts")) return true;
        // Common IDs for a Shorts tab or button (not the home feed's Shorts shelf).
        return id.contains("pivot_shorts") || id.contains("shorts_tab") ||
                id.contains("shorts_nav") || id.contains("shorts_button");
    }

    /** Strong evidence that the *player* has opened; not enough to match a feed shelf. */
    public static boolean playerMarker(CharSequence viewId, CharSequence description) {
        String id = norm(viewId), d = norm(description);
        if (id.contains("reel_watch") || id.contains("reel_player") ||
                id.contains("shorts_watch") || id.contains("shorts_player") ||
                id.contains("shorts_viewer") || id.contains("reel_viewer") ||
                id.contains("reel_watch_page")) return true;
        return d.equals("shorts player") || d.equals("youtube shorts player") ||
                d.equals("shorts video player") || d.equals("shorts viewer") ||
                d.equals("shorts feed") || d.startsWith("shorts video player,");
    }

    /** Some YouTube updates expose the Shorts screen through its window class. */
    public static boolean playerWindow(CharSequence className) {
        String cls = norm(className);
        return cls.contains("shortswatch") || cls.contains("shortsplayer") ||
                cls.contains("reelwatch") || cls.contains("reelplayer") ||
                cls.contains("shortsfeed");
    }
}

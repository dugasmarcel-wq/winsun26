import dev.directonly.ShortsSignals;

public final class ShortsSignalsTest {
    private static int tests;
    static void expect(boolean actual, boolean expected, String msg) {
        tests++;
        if (actual != expected) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        expect(ShortsSignals.shortsClick("Shorts", null, null),true,"Shorts tab tap");
        expect(ShortsSignals.shortsClick(null,"Shorts, selected",null),true,"selected tab");
        expect(ShortsSignals.shortsClick(null,null,"com.google.android.youtube:id/pivot_shorts"),true,"Shorts tab ID");
        expect(ShortsSignals.shortsClick("Shorts documentary",null,null),false,"regular video title");
        expect(ShortsSignals.shortsClick("Home",null,null),false,"Home tab");
        expect(ShortsSignals.shortsClick("Subscriptions",null,null),false,"Subscriptions tab");
        expect(ShortsSignals.shortsClick("Share",null,null),false,"Share action");
        expect(ShortsSignals.playerMarker("com.google.android.youtube:id/reel_watch_fragment",null),true,"shorts watch");
        expect(ShortsSignals.playerMarker("com.google.android.youtube:id/shorts_player",null),true,"Shorts player id");
        expect(ShortsSignals.playerMarker(null,"Shorts player"),true,"Shorts description");
        expect(ShortsSignals.playerMarker(null,"Shorts video player, pause"),true,"Shorts player description");
        expect(ShortsSignals.playerMarker("com.google.android.youtube:id/shorts_shelf",null),false,"regular Home shelf");
        expect(ShortsSignals.playerMarker(null,"Shorts"),false,"Shorts tab is visible on normal Home");
        expect(ShortsSignals.playerMarker("com.google.android.youtube:id/video_player",null),false,"regular video player");
        expect(ShortsSignals.playerMarker(null,"Like"),false,"generic control");
        expect(ShortsSignals.playerWindow("com.google.android.youtube.shorts.ShortsWatchActivity"),true,"shorts window");
        expect(ShortsSignals.playerWindow("com.google.android.youtube.HomeActivity"),false,"Home class");
        expect(ShortsSignals.playerWindow(null),false,"empty class");
        System.out.println("Shorts classification tests passed: "+tests);
    }
}
